<?php
/**
 * This is the CUSTOM MENU ITEMS include template.
 *
 * For a quick explanation of b2evo 2.0 skins, please start here:
 * {@link http://manual.b2evolution.net/Skins_2.0}
 *
 * This is meant to be included in a page template.
 *
 * Russian b2evolution skin	ru.b2evo.net
 *
 */

if( !defined('EVO_MAIN_INIT') ) die( 'Please, do not access this page directly.' );

?>

<!-- Add your custom links here 
<li><a href="#">Custom link 1</a></li>
-->

<!-- These links are right aligned
<li style="float:right"><a href="#">Custom link 2</a></li>
-->